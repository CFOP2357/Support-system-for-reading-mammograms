EXECUTABLES

Executables are found for
 dcm2jpg: Drag and drop DICOM image converter (converts DICOM to PNG,JPEG,BMP)
 ezDICOM.exe: standalone DICOM viewer for Windows
 ezDICOMax.ocx: activeX component for Windows
_________________________________________________________________
SOURCE
The 'Source' folder includes code for these projects as well as the CLX component. Note that ALL PROJECTS use files from the 'COMMON' folder. The 'Source' folder has the following subfolders:

'ACTIVEX'   - code for ActiveX component, plus demo applications for Delphi, VisualBasic, Internet Explorer and Csharp. This module can be used withany ActiveX aware program or compiler.

'CLX' - code for cross platform projects. This CLX module will compile with Delphi (Windows) and Kylix (Linux). A demo application is also included.
 'common'- code used by ALL projects. Either copy these Pascal units to the same folder as the rest of the project you wish to compile, OR add this folder to Delphi's library path. To add these units to the search path, choose 'Environment Options' from the 'Tools' menu, select the Library Tab, add folder to the Library Path listing.
 
'DCM2JPG' - Code for the drag and drop viewer.

'STANDALONE' - Code for two projects: ezDICOM.dpr is the standard ezDICOM executable for Windows, Basic.dpr is a stripped down executable that gives a quick overview of how to view most DICOM images.

_________________________________________________________________
REQUIREMENTS

The ActiveX component requires Delphi 4 or later.
The CLX components require Delphi 6 or later (Windows) or any version of Kylix (Linux)
The standalone and dcm2jpg programs require Delphi 2 or later

_________________________________________________________________
HISTORY

Freeware - Revision History
   rev1 - 1 October 1999 WK
   rev2 - 27 October 1999 CR
   rev4 - 5 November 1999 CR
   rev4 - 16 November 1999 CR
   rev5 - 29 November 1999 CR - GE genesis format
   rev6 - 16 January 2000 CR - latest DICOM.pas included
   rev7 - 20 January 2000 CR - Analyze format, disk caching improves DICOM load times
   rev8 - 6 June 2000 CR - CR Magnetom Vision format, decimal separator set, LUTs
   rev9 - 6 July 2000 CR - CR GE LX format
   rev10 - 1 August 2000 CR - ECAT, RLE DICOM
   rev11 - 7 March 2001 CR/Jakob Scholbach JPEG lossy and lossless DICOM
   rev13 - 20 Feb 2002 CR AFNI and Voxbo support CR/John Skodon [JGS] Better lsJPEG.
   rev14 - 7 March 2002 CR added BSD license, small tweaks to DICOM.pas
   rev15 - 22 June 2002 CR initially assumes recommended contrast settings
   rev16 - 9 October 2002 CR - improved Biorad/Leica/Elscint/Siemens support
   rev18 - 1 January 2003 CR - small tweaks
   rev19 - 14 January 2003 CR - improved comments, better RLE/lsJPEG decompress
   rev20 - 31 March 2003 CR - tweaks to read rare variations of DICOM
   rev21 - 14 May 2003 CR - supports PPM/PGM formats, dcm2jpg can now export DICOM headers to text files
   rev22 - 12 December 2003 CR - improved Philips support

Acknowldegments: Thanks to Earl F. Glynn [www.efg2.com] for useful Delphi graphics and mathematics tutorials.


If you add any new features, Chris Rorden would be
very interested to hear about them.

Contact
===========

E-mail:
 chris.rorden@nottingham.ac.uk
 www.mricro.com



