Public Class Form1
    Inherits System.Windows.Forms.Form
    Dim current_tool As Integer = 0
    Dim colourscheme As Integer = 1
    Dim is_smoothed As Boolean = False
    Dim is_header As Boolean = False
#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call
        AxezDICOMX1.DCMtoolbar() = False
    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents ToolBar1 As System.Windows.Forms.ToolBar
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents MenuItem1 As System.Windows.Forms.MenuItem
    Friend WithEvents OpenMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents SaveMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ExitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem2 As System.Windows.Forms.MenuItem
    Friend WithEvents CopyMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem3 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem4 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem6 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem7 As System.Windows.Forms.MenuItem
    Friend WithEvents zBestFitMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents z50MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents z100MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents z150MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents z200MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents BWMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents HMMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents iBWMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents iHMMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem9 As System.Windows.Forms.MenuItem
    Friend WithEvents MenuItem10 As System.Windows.Forms.MenuItem
    Friend WithEvents AxezDICOMX1 As AxezDICOMax.AxezDICOMX
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ToolBarButton1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolBarButton5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents SmoothMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents ShowHeaderMenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents Mosaic2MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents Mosaic3MenuItem As System.Windows.Forms.MenuItem
    Friend WithEvents mosaic1MenuItem As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.AxezDICOMX1 = New AxezDICOMax.AxezDICOMX()
        Me.ToolBar1 = New System.Windows.Forms.ToolBar()
        Me.ToolBarButton1 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton2 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton3 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton4 = New System.Windows.Forms.ToolBarButton()
        Me.ToolBarButton5 = New System.Windows.Forms.ToolBarButton()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.MenuItem1 = New System.Windows.Forms.MenuItem()
        Me.OpenMenuItem = New System.Windows.Forms.MenuItem()
        Me.SaveMenuItem = New System.Windows.Forms.MenuItem()
        Me.ExitMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem2 = New System.Windows.Forms.MenuItem()
        Me.CopyMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem3 = New System.Windows.Forms.MenuItem()
        Me.MenuItem4 = New System.Windows.Forms.MenuItem()
        Me.zBestFitMenuItem = New System.Windows.Forms.MenuItem()
        Me.z50MenuItem = New System.Windows.Forms.MenuItem()
        Me.z100MenuItem = New System.Windows.Forms.MenuItem()
        Me.z150MenuItem = New System.Windows.Forms.MenuItem()
        Me.z200MenuItem = New System.Windows.Forms.MenuItem()
        Me.SmoothMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem6 = New System.Windows.Forms.MenuItem()
        Me.BWMenuItem = New System.Windows.Forms.MenuItem()
        Me.HMMenuItem = New System.Windows.Forms.MenuItem()
        Me.iBWMenuItem = New System.Windows.Forms.MenuItem()
        Me.iHMMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem7 = New System.Windows.Forms.MenuItem()
        Me.mosaic1MenuItem = New System.Windows.Forms.MenuItem()
        Me.Mosaic2MenuItem = New System.Windows.Forms.MenuItem()
        Me.Mosaic3MenuItem = New System.Windows.Forms.MenuItem()
        Me.ShowHeaderMenuItem = New System.Windows.Forms.MenuItem()
        Me.MenuItem9 = New System.Windows.Forms.MenuItem()
        Me.MenuItem10 = New System.Windows.Forms.MenuItem()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.Panel1.SuspendLayout()
        CType(Me.AxezDICOMX1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.Controls.AddRange(New System.Windows.Forms.Control() {Me.AxezDICOMX1})
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel1.DockPadding.Top = 32
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(520, 497)
        Me.Panel1.TabIndex = 0
        '
        'AxezDICOMX1
        '
        Me.AxezDICOMX1.ContainingControl = Me
        Me.AxezDICOMX1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.AxezDICOMX1.Location = New System.Drawing.Point(0, 32)
        Me.AxezDICOMX1.Name = "AxezDICOMX1"
        Me.AxezDICOMX1.OcxState = CType(resources.GetObject("AxezDICOMX1.OcxState"), System.Windows.Forms.AxHost.State)
        Me.AxezDICOMX1.Size = New System.Drawing.Size(520, 465)
        Me.AxezDICOMX1.TabIndex = 0
        '
        'ToolBar1
        '
        Me.ToolBar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.ToolBarButton1, Me.ToolBarButton2, Me.ToolBarButton3, Me.ToolBarButton4, Me.ToolBarButton5})
        Me.ToolBar1.ButtonSize = New System.Drawing.Size(24, 24)
        Me.ToolBar1.DropDownArrows = True
        Me.ToolBar1.ImageList = Me.ImageList1
        Me.ToolBar1.Name = "ToolBar1"
        Me.ToolBar1.ShowToolTips = True
        Me.ToolBar1.Size = New System.Drawing.Size(520, 27)
        Me.ToolBar1.TabIndex = 1
        '
        'ToolBarButton1
        '
        Me.ToolBarButton1.ImageIndex = 0
        Me.ToolBarButton1.Tag = "1"
        '
        'ToolBarButton2
        '
        Me.ToolBarButton2.ImageIndex = 1
        Me.ToolBarButton2.Tag = "2"
        '
        'ToolBarButton3
        '
        Me.ToolBarButton3.ImageIndex = 2
        Me.ToolBarButton3.Tag = "3"
        '
        'ToolBarButton4
        '
        Me.ToolBarButton4.ImageIndex = 3
        Me.ToolBarButton4.Tag = "4"
        '
        'ToolBarButton5
        '
        Me.ToolBarButton5.ImageIndex = 4
        Me.ToolBarButton5.Tag = "5"
        '
        'ImageList1
        '
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Olive
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem1, Me.MenuItem2, Me.MenuItem3, Me.MenuItem9})
        '
        'MenuItem1
        '
        Me.MenuItem1.Index = 0
        Me.MenuItem1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.OpenMenuItem, Me.SaveMenuItem, Me.ExitMenuItem})
        Me.MenuItem1.Text = "File"
        '
        'OpenMenuItem
        '
        Me.OpenMenuItem.Index = 0
        Me.OpenMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlO
        Me.OpenMenuItem.Text = "Open"
        '
        'SaveMenuItem
        '
        Me.SaveMenuItem.Index = 1
        Me.SaveMenuItem.Shortcut = System.Windows.Forms.Shortcut.CtrlS
        Me.SaveMenuItem.Text = "Save as bitmap"
        '
        'ExitMenuItem
        '
        Me.ExitMenuItem.Index = 2
        Me.ExitMenuItem.Text = "E&xit"
        '
        'MenuItem2
        '
        Me.MenuItem2.Index = 1
        Me.MenuItem2.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.CopyMenuItem})
        Me.MenuItem2.Text = "Edit"
        '
        'CopyMenuItem
        '
        Me.CopyMenuItem.Index = 0
        Me.CopyMenuItem.Text = "Copy"
        '
        'MenuItem3
        '
        Me.MenuItem3.Index = 2
        Me.MenuItem3.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem4, Me.SmoothMenuItem, Me.MenuItem6, Me.MenuItem7, Me.ShowHeaderMenuItem})
        Me.MenuItem3.Text = "View"
        '
        'MenuItem4
        '
        Me.MenuItem4.Index = 0
        Me.MenuItem4.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.zBestFitMenuItem, Me.z50MenuItem, Me.z100MenuItem, Me.z150MenuItem, Me.z200MenuItem})
        Me.MenuItem4.Text = "Zoom"
        '
        'zBestFitMenuItem
        '
        Me.zBestFitMenuItem.Index = 0
        Me.zBestFitMenuItem.RadioCheck = True
        Me.zBestFitMenuItem.Text = "Best Fit"
        '
        'z50MenuItem
        '
        Me.z50MenuItem.Index = 1
        Me.z50MenuItem.RadioCheck = True
        Me.z50MenuItem.Text = "50%"
        '
        'z100MenuItem
        '
        Me.z100MenuItem.Checked = True
        Me.z100MenuItem.Index = 2
        Me.z100MenuItem.RadioCheck = True
        Me.z100MenuItem.Text = "100%"
        '
        'z150MenuItem
        '
        Me.z150MenuItem.Index = 3
        Me.z150MenuItem.RadioCheck = True
        Me.z150MenuItem.Text = "150%"
        '
        'z200MenuItem
        '
        Me.z200MenuItem.Index = 4
        Me.z200MenuItem.RadioCheck = True
        Me.z200MenuItem.Text = "200%"
        '
        'SmoothMenuItem
        '
        Me.SmoothMenuItem.Checked = True
        Me.SmoothMenuItem.Index = 1
        Me.SmoothMenuItem.Text = "Smooth"
        '
        'MenuItem6
        '
        Me.MenuItem6.Index = 2
        Me.MenuItem6.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.BWMenuItem, Me.HMMenuItem, Me.iBWMenuItem, Me.iHMMenuItem})
        Me.MenuItem6.Text = "Color Scheme"
        '
        'BWMenuItem
        '
        Me.BWMenuItem.Checked = True
        Me.BWMenuItem.Index = 0
        Me.BWMenuItem.RadioCheck = True
        Me.BWMenuItem.Text = "Black and White"
        '
        'HMMenuItem
        '
        Me.HMMenuItem.Index = 1
        Me.HMMenuItem.RadioCheck = True
        Me.HMMenuItem.Text = "Hot Metal"
        '
        'iBWMenuItem
        '
        Me.iBWMenuItem.Index = 2
        Me.iBWMenuItem.RadioCheck = True
        Me.iBWMenuItem.Text = "Inverted Black and White"
        '
        'iHMMenuItem
        '
        Me.iHMMenuItem.Index = 3
        Me.iHMMenuItem.RadioCheck = True
        Me.iHMMenuItem.Text = "Inverted Hot Metal"
        '
        'MenuItem7
        '
        Me.MenuItem7.Index = 3
        Me.MenuItem7.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mosaic1MenuItem, Me.Mosaic2MenuItem, Me.Mosaic3MenuItem})
        Me.MenuItem7.Text = "Mosaic"
        '
        'mosaic1MenuItem
        '
        Me.mosaic1MenuItem.Checked = True
        Me.mosaic1MenuItem.Index = 0
        Me.mosaic1MenuItem.RadioCheck = True
        Me.mosaic1MenuItem.Text = "1x1"
        '
        'Mosaic2MenuItem
        '
        Me.Mosaic2MenuItem.Index = 1
        Me.Mosaic2MenuItem.RadioCheck = True
        Me.Mosaic2MenuItem.Text = "2x2"
        '
        'Mosaic3MenuItem
        '
        Me.Mosaic3MenuItem.Index = 2
        Me.Mosaic3MenuItem.RadioCheck = True
        Me.Mosaic3MenuItem.Text = "3x3"
        '
        'ShowHeaderMenuItem
        '
        Me.ShowHeaderMenuItem.Index = 4
        Me.ShowHeaderMenuItem.Text = "Show Header"
        '
        'MenuItem9
        '
        Me.MenuItem9.Index = 3
        Me.MenuItem9.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.MenuItem10})
        Me.MenuItem9.Text = "About"
        '
        'MenuItem10
        '
        Me.MenuItem10.Index = 0
        Me.MenuItem10.Text = "ezDICOM in Visual Basic"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "doc1"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(520, 497)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.ToolBar1, Me.Panel1})
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Menu = Me.MainMenu1
        Me.Name = "Form1"
        Me.Text = "ezDICOM in Visual Basic"
        Me.Panel1.ResumeLayout(False)
        CType(Me.AxezDICOMX1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub OpenMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenMenuItem.Click
        Dim fn As String
        OpenFileDialog1.ShowDialog()
        fn = OpenFileDialog1.FileName
        AxezDICOMX1.DCMfilename = fn
    End Sub

    Private Sub ToolBar1_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles ToolBar1.ButtonClick
        ToolBar1.Buttons([current_tool]).Pushed() = False
        current_tool = Convert.ToInt32(e.Button.Tag) - 1
        ToolBar1.Buttons([current_tool]).Pushed() = True
        AxezDICOMX1.DCMtool = 1 + current_tool
    End Sub

    Private Sub MenuItem10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MenuItem10.Click
        MessageBox.Show("Visual Basic demo of EZDicom by Tom Womack. Demonstrates use of the ActiveX component " + AxezDICOMX1.DCMversionInfo)

    End Sub

    Private Sub SmoothOnMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SmoothMenuItem.Click
        AxezDICOMX1.DCMsmoothOn = Not AxezDICOMX1.DCMsmoothOn
        SmoothMenuItem.Checked = AxezDICOMX1.DCMsmoothOn
    End Sub

    Private Sub ExitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitMenuItem.Click
        Application.Exit()
    End Sub

    Private Sub CopyMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyMenuItem.Click
        Dim a As Boolean

        If AxezDICOMX1.DCMshowHeader Then
            a = AxezDICOMX1.DCMcopyHeader2Clipboard
        Else
            a = AxezDICOMX1.DCMcopyImage2Clipboard
        End If

    End Sub

    Private Sub SaveMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveMenuItem.Click
        Dim a As DialogResult
        SaveFileDialog1.Filter = "Bitmap file|*.BMP|JPEG file|*.JPG"
        a = SaveFileDialog1.ShowDialog()
        If (a = DialogResult.OK) Then
            AxezDICOMX1.DCMsaveToFile = SaveFileDialog1.FileName
        End If
    End Sub

    Private Sub ShowHeaderMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShowHeaderMenuItem.Click
        AxezDICOMX1.DCMshowHeader = Not AxezDICOMX1.DCMshowHeader
        ShowHeaderMenuItem.Checked = AxezDICOMX1.DCMshowHeader
    End Sub

    Private Sub zBestFitMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles zBestFitMenuItem.Click, z100MenuItem.Click, z50MenuItem.Click, z150MenuItem.Click, z200MenuItem.Click
        Dim x As MenuItem
        For Each x In MenuItem4.MenuItems
            x.Checked = False
        Next
        x = CType(sender, MenuItem)
        x.Checked = True

        If (x Is zBestFitMenuItem) Then
            AxezDICOMX1.DCMbestFitZoom = True
        Else
            AxezDICOMX1.DCMbestFitZoom = False
            If (x Is z50MenuItem) Then AxezDICOMX1.DCMzoomPct = 50
            If (x Is z100MenuItem) Then AxezDICOMX1.DCMzoomPct = 100
            If (x Is z150MenuItem) Then AxezDICOMX1.DCMzoomPct = 150
            If (x Is z200MenuItem) Then AxezDICOMX1.DCMzoomPct = 200
        End If
    End Sub

    Private Sub BWMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BWMenuItem.Click, HMMenuItem.Click, iBWMenuItem.Click, iHMMenuItem.Click
        Dim x As MenuItem

        For Each x In MenuItem6.MenuItems
            x.Checked = False
        Next
        CType(sender, MenuItem).Checked = True
        x = CType(sender, MenuItem)
        If (x Is BWMenuItem) Then AxezDICOMX1.DCMcolorScheme = 1
        If (x Is iBWMenuItem) Then AxezDICOMX1.DCMcolorScheme = -1
        If (x Is HMMenuItem) Then AxezDICOMX1.DCMcolorScheme = 2
        If (x Is iHMMenuItem) Then AxezDICOMX1.DCMcolorScheme = -2
    End Sub

    Private Sub mosaicMenuClick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles mosaic1MenuItem.Click, Mosaic2MenuItem.Click, Mosaic3MenuItem.Click
        Dim nmos As Integer, x As MenuItem

        For Each x In MenuItem7.MenuItems
            x.Checked = False
        Next

        x = CType(sender, MenuItem)
        If (x Is mosaic1MenuItem) Then nmos = 1
        If (x Is Mosaic2MenuItem) Then nmos = 2
        If (x Is Mosaic3MenuItem) Then nmos = 3

        x.Checked = True
        AxezDICOMX1.DCMmosaicRows = nmos
        AxezDICOMX1.DCMmosaicFirstSlice = 1
        AxezDICOMX1.DCMmosaicLastSlice = 9999
        AxezDICOMX1.DCMmosaicCols = nmos
    End Sub

End Class
