Delphi DICOM ActiveX Demo

This file includes a Demo of my ActiveX component. 

To install with Delphi:

Launch Delphi and choose 'Import ActiveX Control' from
the 'Component' menu. Then 'Add' and 'Install' the 
component 'DCMaxPro.OCX' that is included in this folder.
Once you have installed the component, you should see
the 'DCMax' component on the 'ActiveX' tab of your 
component toolbar. You can simply drag and drop the 
component onto your project forms.

Next, you can open the sample project. Simply select 
'Open' from the 'File' menu and select the file
'Project1.dpr'.

For more details, please contact:
 chris.rorden@nottingham.ac.uk