To load the package with the CLX component for Delphi 6 or Kylix:

Choose 'Install Component' from the 'Component' menu.

Click on the 'Add' button and select the file "QDCMImage.pas".

Press the "Install" button to install the component.
A new item named "DCMImage" appears on your "Standard" toolbar.
With Windows, you only see this tool when creating CLX applications
(choose "CLX Application" from the "New" item of the "File" menu).
In Linux, you will always see the component. To use the component,
simply drag and drop the component onto your project. You can adjust the
settings in the IDE or at runtime. For details, please see:
 http://www.psychology.nottingham.ac.uk/staff/cr1/dicomcom.html
or
 http://www.mricro.com/dicomcom.html

You may now want to open the demo project "DCMtestProj.dpr"
which is in the "demo" folder. NOTE: First install the DCMImage component
as described above before compiling the project.
To build the project, simply open the project with Delphi or Kylix and
then choose "Run" from the "Run" menu.
The demo folder also includes a sample DICOM image named
"1MR-MONON2-8-16x-heart.dcm". You can view this image
to make sure the demo project is working correctly.

